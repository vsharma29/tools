#!/usr/bin/env bash

DOCKER_IMAGE="awscli-helm-kubectl"
DOCKER_TAG="1.1"

docker build \
	  --build-arg BUILD_DATE=`date -u +"%Y-%m-%dT%H:%M:%SZ"` \
	  -t ${DOCKER_IMAGE}:${DOCKER_TAG} .


docker push ${DOCKER_IMAGE}:${DOCKER_TAG}