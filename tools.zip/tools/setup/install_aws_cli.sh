#!/usr/bin/env bash

#aws-cli/1.18.115 Python/2.7.18rc1 Linux/5.4.0-42-generic botocore/1.17.38
set -e
set -x

echo "$HOME"

TARGET_DIR="/usr/local/bin"

#check if docker is already installed
if [ -e $TARGET_DIR/aws ]; then
  CURRENT=$($TARGET_DIR/aws --version)
  echo "Current Version :  $CURRENT"
  echo $TARGET_DIR/aws already exists. Please remove and install again.
  exit 1
fi

curl "https://s3.amazonaws.com/aws-cli/awscli-bundle.zip" -o "awscli-bundle.zip"
unzip awscli-bundle.zip

sudo ./awscli-bundle/install -i /usr/local/aws -b $TARGET_DIR/aws

#cleanup
rm awscli-bundle.zip

echo aws --version
echo "Completed installing AWS CLI!!"
