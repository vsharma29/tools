#!/usr/bin/env bash

# Version: 19.03.12
set -e
set -x

DOCKER_USER=$1

echo "$HOME"

TARGET_DIR="/usr/local/bin"

#check if docker is already installed
if [ -e $TARGET_DIR/docker ]; then
  echo "Version :" $($TARGET_DIR/docker version)
  echo "$TARGET_DIR"/docker already exists. Please remove and install again.
  exit 1
fi

curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

echo "$TARGET_DIR"/docker version
echo "Completed installing docker!!"

if [ $# -eq 1 ]; then
  sudo usermod -aG docker "$DOCKER_USER"
fi
