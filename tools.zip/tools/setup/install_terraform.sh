#!/usr/bin/env bash

#Version : Terraform v0.13.1
set -e
set -x

echo "$HOME"

TARGET_DIR="/usr/local/bin"

#check if docker is already installed
if [ -e $TARGET_DIR/terraform ]; then
  echo "Version :" $($TARGET_DIR/terraform -v)
  echo "$TARGET_DIR"/terraform already exists. Please remove and install again.
  exit 1
fi

TER_VER=0.13.1
wget https://releases.hashicorp.com/terraform/${TER_VER}/terraform_${TER_VER}_linux_amd64.zip

unzip terraform_${TER_VER}_linux_amd64.zip

sudo mv terraform $TARGET_DIR

#cleanup
rm terraform_${TER_VER}_linux_amd64.zip

echo terraform -v
echo "Completed installing terraform!!"
