#!/usr/bin/env bash

#Version:"v1.18.6"
set -e
set -x

echo "$HOME"

TARGET_DIR="/usr/local/bin"

#check if docker is already installed
if [ -e $TARGET_DIR/kubectl ]; then
  CURRENT=$($TARGET_DIR/kubectl version --client)
  echo "Current Version :  $CURRENT"
  echo $TARGET_DIR/kubectl already exists. Please remove and install again.
  exit 1
fi

curl -LO "https://storage.googleapis.com/kubernetes-release/release/$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)/bin/linux/amd64/kubectl"
chmod +x ./kubectl

sudo mv ./kubectl $TARGET_DIR

#cleanup

echo kubectl version --client
echo "Completed installing kubectl!!"



