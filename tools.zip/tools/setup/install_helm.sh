#!/usr/bin/env bash

#Version :  v3.3.0-rc.1+g5c2dfaa
set -e
set -x

echo "$HOME"

TARGET_DIR="/usr/local/bin"

#check if docker is already installed
if [ -e $TARGET_DIR/helm ]; then
  CURRENT=$($TARGET_DIR/helm version --short)
  echo "Current Version :  $CURRENT"
  echo $TARGET_DIR/helm already exists. Please remove and install again.
  exit 1
fi

curl -k -o helm.tar.gz https://get.helm.sh/helm-v3.3.0-rc.1-linux-amd64.tar.gz
tar -zxvf helm.tar.gz

sudo mv linux-amd64/helm $TARGET_DIR

#cleanup
rm helm.tar.gz
rm -r ./linux-amd64/

echo helm version --short
echo "Completed installing helm!!"
