#!/usr/bin/env bash

sh install_docker.sh
sh install_kubectl.sh
sh install_helm.sh
sh install_terraform.sh
sh install_aws_cli.sh

sudo apt-get install curl wget unzip git python